package org.koreait.wishlist.constants;

public enum WishType {
    POKEMON,
    BOARD
}
