package org.koreait.product.constants;


public enum DiscountType {
    FIXED, //고정가 할인
    RATE, //할인율
    NONE // 할인 없음
}
