package org.koreait.message.services;

import lombok.Data;
import org.springframework.stereotype.Service;

@Data
public class MessageSearch {
}
