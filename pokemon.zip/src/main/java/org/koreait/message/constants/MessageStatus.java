package org.koreait.message.constants;

public enum MessageStatus {
    READ, // 열람
    UNREAD // 미열람
}
