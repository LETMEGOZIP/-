package org.koreait.mypage.controllers;

import lombok.Data;

@Data
public class RequestProfile {
    private String name;
    private String nickName;
    private String password;
    private String confirmPassword;
    private String email; // ----------------- 임시추가
}