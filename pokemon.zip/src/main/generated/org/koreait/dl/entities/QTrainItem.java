package org.koreait.dl.entities;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QTrainItem is a Querydsl query type for TrainItem
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QTrainItem extends EntityPathBase<TrainItem> {

    private static final long serialVersionUID = 1994610417L;

    public static final QTrainItem trainItem = new QTrainItem("trainItem");

    public final org.koreait.global.entities.QBaseEntity _super = new org.koreait.global.entities.QBaseEntity(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    public final NumberPath<Integer> item1 = createNumber("item1", Integer.class);

    public final NumberPath<Integer> item10 = createNumber("item10", Integer.class);

    public final NumberPath<Integer> item2 = createNumber("item2", Integer.class);

    public final NumberPath<Integer> item3 = createNumber("item3", Integer.class);

    public final NumberPath<Integer> item4 = createNumber("item4", Integer.class);

    public final NumberPath<Integer> item5 = createNumber("item5", Integer.class);

    public final NumberPath<Integer> item6 = createNumber("item6", Integer.class);

    public final NumberPath<Integer> item7 = createNumber("item7", Integer.class);

    public final NumberPath<Integer> item8 = createNumber("item8", Integer.class);

    public final NumberPath<Integer> item9 = createNumber("item9", Integer.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> modifiedAt = _super.modifiedAt;

    public final NumberPath<Integer> result = createNumber("result", Integer.class);

    public QTrainItem(String variable) {
        super(TrainItem.class, forVariable(variable));
    }

    public QTrainItem(Path<? extends TrainItem> path) {
        super(path.getType(), path.getMetadata());
    }

    public QTrainItem(PathMetadata metadata) {
        super(TrainItem.class, metadata);
    }

}

