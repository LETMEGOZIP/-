/**
* 파일 업로드 후 후속 처리
*/

function callbackFileUpload(files){
    console.log("files", files);
}